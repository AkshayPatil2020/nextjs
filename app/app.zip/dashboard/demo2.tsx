import React from 'react'

function demo2() {
  return (
    <div>demo2</div>
  )
}

export default demo2;