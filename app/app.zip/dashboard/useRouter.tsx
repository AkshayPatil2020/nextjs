'use client';

import React from 'react';
import {useRouter} from 'next/navigation';

function useRouterFun() {
    const routerLink = useRouter();
    return (
      <button type='button' onClick={() => routerLink.push('/')}>useRouter Link</button>
  )
}

export default useRouterFun