import React from 'react';
import Link from 'next/link';
import UseRouterFun from './useRouter';

function Dashboard() {
    return (
        <>
            <Link href="/dashboard">Dashboard</Link> <br />
            <UseRouterFun />
        </>
  )
}

export default Dashboard;