'use client'
import { usePathname } from 'next/navigation';

/* function SecondRouteGroup() {
    const router = usePathname();
  console.log(router);
  return (
    <div>SecondRouteGroup + 2</div>
  )
}

export default SecondRouteGroup; */

async function generateStaticParams() {
    const pathname = usePathname();
    const returnPath = pathname.replace('/', '');
    console.log(returnPath);
    return Number(returnPath) ? returnPath : 'New Folder';
}

export default generateStaticParams;