import React from 'react'

function FirstRouteGroup() {
  return (
    <div>FirstRouteGroup</div>
  )
}

export default FirstRouteGroup